from openpyxl import load_workbook

def baca_data():
    workbook = load_workbook(
        "DataNilai.xlsx", data_only=True
    )
    sheet = workbook["Data-nilai"]

    mahasiswa = []
    baris = 2

    while baris <= sheet.max_row:
        nama = sheet.cell(baris, 1).value
        nilai_lain = sheet.cell(baris, 3).value
        uts = sheet.cell(baris, 4).value
        uas = sheet.cell(baris, 5).value

        if nama is not None:
            mahasiswa.append(
                [nama, nilai_lain, uts, uas]
            )

        baris += 1

    workbook.close()
    return mahasiswa

def hitung_nilai(nilai_lain, uts, uas):
    na = (
        0.30 * nilai_lain
        + 0.35 * uts
        + 0.35 * uas
    )
    return na

def tentukan_grade(na):
    if na >= 85:
        return "A"
    elif na >= 80:
        return "A-"
    elif na >= 75:
        return "B+"
    elif na >= 70:
        return "B-"
    elif na >= 65:
        return "C+"
    elif na >= 60:
        return "C-"
    else:
        return "Tidak Lulus"

def tampilkan_laporan(mahasiswa):
    print("\nLaporan Grading Mahasiswa")
    print("-" * 65)

    print(
        f"{'No':<5}"
        f"{'Nama Mahasiswa':<25}"
        f"{'Nilai Akhir':<18}"
        f"{'Grade':<15}"
    )
    print("-" * 65)

    hasil = []
    i = 0

    while i < len(mahasiswa):
        nama, nilai_lain, uts, uas = mahasiswa[i]

        na = hitung_nilai(nilai_lain, uts, uas)
        grade = tentukan_grade(na)

        print(
            f"{i + 1:<5}"
            f"{nama:<25}"
            f"{na:<18.2f}"
            f"{grade:<15}"
        )

        hasil.append([nama, na, grade])
        i += 1
    print("-" * 65)

    return hasil

def tampilkan_rekap(hasil):
    counter = {
        "A": 0,
        "A-": 0,
        "B+": 0,
        "B-": 0,
        "C+": 0,
        "C-": 0,
        "Tidak Lulus": 0
    }

    i = 0

    while i < len(hasil):
        grade = hasil[i][2]
        counter[grade] += 1
        i += 1

    print("\nRekapitulasi:")

    grade_list = [
        "A", "A-", "B+", "B-", "C+", "C-",
        "Tidak Lulus"
    ]

    i = 0

    while i < len(grade_list):
        grade = grade_list[i]
        print(f"Grade {grade} = {counter[grade]}")
        i += 1

    print(f"\nTotal Mahasiswa = {len(hasil)}")

def main():
    print("Program Grading")
    print("Nama: Tiara Novita Sari")
    print("NIM: 1306625008")

    mahasiswa = baca_data()
    hasil = tampilkan_laporan(mahasiswa)
    tampilkan_rekap(hasil)

    print("\n=SELESAI=")

main()