print("Program Faktor Bilangan")
print("Nama: Tiara Novita Sari")
print("NIM: 1306625008")
print()

while True:
    N = int(input("Masukan sembarang bilangan < 100 (masukkan 0 untuk selesai) = "))

    if N == 0:
        print()
        print("SELESAI")
        break

    faktor = []

    for i in range(1, N + 1):
        if N % i == 0:
            faktor.append(i)

    print(f"Bilangan {N} → faktornya = {faktor}")
    print()