import math

# Fungsi sinus dengan deret Maclaurin
def sinus(x, n):
    hasil = 0

    for i in range(n):
        suku = ((-1) ** i) * (x ** (2 * i + 1)) / math.factorial(2 * i + 1)
        hasil = hasil + suku

    return hasil

# Fungsi cosinus dengan deret Maclaurin
def cosinus(x, n):
    hasil = 0

    for i in range(n):
        suku = ((-1) ** i) * (x ** (2 * i)) / math.factorial(2 * i)
        hasil = hasil + suku

    return hasil

# Fungsi Relative Error
def error(AV, TV):
    ER = abs((AV - TV) / TV) * 100

    return ER

# Program utama
while True:

    print("Program Sinus-Cosinus")
    print("Nama: Tiara Novita Sari")
    print("NIM: 1306625008")

    # Input sudut
    derajat = float(input("Besar sudut (derajat) = "))

    # Konversi derajat ke radian
    x = math.radians(derajat)

    # True Value
    TV_sin = math.sin(x)
    TV_cos = math.cos(x)

    print(f"\nTrue Value sin ({derajat}) = {TV_sin:.6f}")
    print(f"True Value cos ({derajat}) = {TV_cos:.6f}")

    # Header tabel
    print("\n" + "-" * 90)
    print(f"{'Jumlah suku':<15}{'AV sinus':<15}{'ER sinus':<15}"
          f"{'AV cosinus':<15}{'ER cos':<10}")
    print("-" * 90)

    # Inisialisasi jumlah suku
    n = 1

    while True:

        # Memanggil def sinus
        AV_sin = sinus(x, n)

        # Memanggil def cosinus
        AV_cos = cosinus(x, n)

        # Memanggil def error
        ER_sin = error(AV_sin, TV_sin)
        ER_cos = error(AV_cos, TV_cos)

        # Menampilkan hasil
        print(f"{n:<15}{AV_sin:<15.6f}{ER_sin:<15.2f}"
              f"{AV_cos:<15.6f}{ER_cos:<10.2f}")

        # Cek error
        if ER_sin < 5 and ER_cos < 5:
            break

        # Menambah jumlah suku
        n = n + 1

    print("-" * 90)

    # Menghitung kembali?
    ulang = input("\nMau menghitung lagi (y/t)? ")

    if ulang == "t":
        print("SELESAI")
        break