print("Nama: Tiara Novita Sari")
print("NIM: 1306625008")
print("Kelas: Fisika C")
suhu_awal = float(input("Suhu Awal: "))
suhu_akhir = float(input("Suhu Akhir: "))
selang = float(input("Selang: "))

# Judul tabel
print("\nTabel Konversi Suhu")

# Garis atasnya
print("+------+------------+------------+--------------+")
# Header tabel
print("| {:<4} | {:<10} | {:<10} | {:<12} |".format(
    "No.", "Celcius", "Reamur", "Fahrenheit"))

# Penutup header tabel
print("+------+------------+------------+--------------+")

no = 1
celcius = suhu_awal
while celcius <= suhu_akhir:
    fahrenheit = (celcius * 9/5) + 32
    reamur = celcius * 4/5
    print("| {:<4} | {:<10.2f} | {:<10.2f} | {:<12.2f} |".format(
        no, celcius, reamur, fahrenheit))
    celcius += selang
    no += 1

# Garis bawah tabel
print("+------+------------+------------+--------------+")

print("selesai")

input("Tekan Enter untuk keluar...")