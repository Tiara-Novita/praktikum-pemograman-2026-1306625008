import pygame, sys, math, array
from pygame.locals import *

def GambarBackground():
    layar.fill(ungu)
    # lantai: garis hitam di bagian paling bawah
    pygame.draw.line(layar, black, [0, Lantai], [Lebar, Lantai], TebalLantai)
    # tulisan background
    layar.blit(text1, [355, 5])

def BuatSuara(frekuensi, durasi, volume=0.5):
    # membuat efek suara sederhana (nada yang meredup) tanpa file eksternal
    freq_mixer, format_mixer, kanal = pygame.mixer.get_init()
    n = int(freq_mixer * durasi)
    buf = array.array('h')
    for i in range(n):
        envelope = 1 - i / n
        nilai = int(32767 * volume * envelope * math.sin(2 * math.pi * frekuensi * i / freq_mixer))
        for _ in range(kanal):
            buf.append(nilai)
    return pygame.mixer.Sound(buffer=buf.tobytes())

def GerakanBolaJatuh(b0XX, b0YY):
    vb0 = 0          # kecepatan awal bola (pixel/clock)
    g = 0.8          # percepatan gravitasi (pixel/clock^2)
    e = 0.7          # koefisien pantulan (0-1), makin kecil makin cepat diam
    batas_diam = 2   # jika kecepatan benturan di bawah ini, bola berhenti
    GB = True        # GB = gerak bola

    suara_jatuh.play()   # sound effect saat bola mulai jatuh

    while GB == True:
        for event in pygame.event.get():     # supaya jendela tetap bisa ditutup
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        vb0 = vb0 + g            # kecepatan bertambah karena gravitasi
        b0YY = b0YY + vb0        # posisi bola-0

        # bola menyentuh lantai
        if b0YY >= PermukaanLantai - RBola:
            b0YY = PermukaanLantai - RBola
            if abs(vb0) < batas_diam:
                vb0 = 0
                GB = False                       # bola diam di lantai
            else:
                # volume suara pantulan mengikuti kerasnya benturan
                suara_pantul.set_volume(min(1.0, abs(vb0) / 25))
                suara_pantul.play()
                vb0 = -vb0 * e                   # arah berbalik, kecepatan berkurang

        GambarBackground()
        pygame.draw.circle(layar, white, [b0XX, int(b0YY)], RBola)
        pygame.display.flip()
        fpsClock.tick(fps)
    return b0XX, b0YY


# Initialize Pygame
pygame.init()

# Define some colors
white = (250,250,250);   whitdull = (243,243,242)
black = (70,70,70)
ungu = (128,0,128)      # ungu

# Setting font-size
font1 = pygame.font.Font(None, 30)
# Penentuan isi tulisan
text1 = font1.render("Simulasi Bola Jatuh Bebas", True, white)

# preparing the screen
Lebar = 1050 ; Tinggi = 600
layar = pygame.display.set_mode([Lebar, Tinggi])
layar.fill(ungu)      # Setting warna latar belakang

# Data lantai dan bola
TebalLantai = 10
Lantai = Tinggi - TebalLantai // 2           # posisi tengah garis lantai
PermukaanLantai = Lantai - TebalLantai // 2  # sisi atas garis lantai
RBola = 20                                   # jari-jari bola

# Inisiasi suara
click_sound = pygame.mixer.Sound("click.wav")
suara_jatuh = BuatSuara(300, 0.25, 0.4)      # nada rendah saat mulai jatuh
suara_pantul = BuatSuara(180, 0.15, 0.8)     # "bug" saat memantul

# penetapan harga awal
xm, ym = 0, 0                      # koord mouse
b0X = 525; b0Y = 50                # posisi awal bola

fps = 60
fpsClock = pygame.time.Clock()


# program utama Pygame
done = False
while done == False:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

        if event.type == pygame.MOUSEBUTTONDOWN:
            click_sound.play()
            b0Y = 50                   # bola dikembalikan ke atas setiap klik
            b0X, b0Y = GerakanBolaJatuh(b0X, b0Y)

    GambarBackground()
    pygame.draw.circle(layar, white, [b0X, int(b0Y)], RBola)   # Gambar Bola

    # Tampilkan semua gambar di layar
    pygame.display.flip()

    # Get the current mouse position (x,y)
    player_position = pygame.mouse.get_pos()
    xm = player_position[0]
    ym = player_position[1]

# end program
pygame.quit()